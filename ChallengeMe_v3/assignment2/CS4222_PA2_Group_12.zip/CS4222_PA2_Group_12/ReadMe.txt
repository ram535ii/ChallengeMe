Read Me - Assignment 2

Group 12

Constantijn Schepens - A0121003
Cai Shuai - A0077226
Daryl Rodrigo - A0120775

Qoute received - One should always look for a possible alternative, and provide against it.
Book - The Adventure of Black Peter
Page - 559